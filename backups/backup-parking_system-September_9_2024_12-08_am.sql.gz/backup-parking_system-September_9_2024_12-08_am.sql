CREATE DATABASE IF NOT EXISTS `parking_system`;

USE parking_system;

DROP TABLE IF EXISTS `user_details`;

CREATE TABLE `user_details` (
  `user_d_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `firstname` varchar(32) NOT NULL,
  `lastname` varchar(32) NOT NULL,
  `middlename` varchar(32) NOT NULL,
  `department` int(2) NOT NULL,
  `year_group` int(2) NOT NULL,
  `section` varchar(32) NOT NULL,
  `mv_file` varchar(32) NOT NULL,
  `body_number` text NOT NULL,
  PRIMARY KEY (`user_d_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `user_details` VALUES("1","3","Jobert","Simbre","Gosuico","1","1","1","12312312","21321123");
INSERT INTO `user_details` VALUES("2","4","Jobert","Simbre","Gosuico","1","1","1","12312312","12312312");



DROP TABLE IF EXISTS `user_logs`;

CREATE TABLE `user_logs` (
  `user_log_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `username` text NOT NULL,
  `action` text NOT NULL,
  PRIMARY KEY (`user_log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `user_logs` VALUES("1","1"," ","Logged to the system");
INSERT INTO `user_logs` VALUES("2","1"," ","Logged to the system");
INSERT INTO `user_logs` VALUES("3","1"," ","Logged to the system");
INSERT INTO `user_logs` VALUES("4","1"," ","Logged out on the system");
INSERT INTO `user_logs` VALUES("5","1","Administrator","Logged to the system");
INSERT INTO `user_logs` VALUES("6","1","Administrator","Logged to the system");
INSERT INTO `user_logs` VALUES("7","1","Administrator","Backup the database named backup-parking_system-September_9_2024_12-08_am.sql.gz");



DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_type` int(11) NOT NULL DEFAULT 2,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `users` VALUES("1","admin@access.com","$2y$10$N.SRTPJ9o63NISilP0gH..1naevj1Juu/k7N3un19QWW0aoqhptNq","2024-09-08 23:37:38","2024-09-08 23:37:38","1");
INSERT INTO `users` VALUES("3","jobert.simbre014@gmail.com","$2y$10$HWt7Mc0lK5eyU5WWRpONAux9axFc1geFTYD2pXiw/LNfn9FdPhbua","2024-09-09 02:18:38","2024-09-09 02:18:38","2");
INSERT INTO `users` VALUES("4","jobert.simbre14@gmail.com","$2y$10$hciRPzyIrxPfzzrize8kzuUsMKJ/BzL7vnGmq9I8OvPVl.40rjpdC","2024-09-09 02:56:56","2024-09-09 02:56:56","2");
