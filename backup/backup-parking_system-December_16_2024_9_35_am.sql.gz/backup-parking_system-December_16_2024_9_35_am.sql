CREATE DATABASE IF NOT EXISTS `parking_system`;

USE parking_system;

DROP TABLE IF EXISTS `parking_log`;

CREATE TABLE `parking_log` (
  `parking_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_mv_file` int(11) NOT NULL,
  `time_in` timestamp NOT NULL DEFAULT current_timestamp(),
  `time_out` timestamp NULL DEFAULT NULL,
  `username` text NOT NULL,
  `parking_date` date NOT NULL,
  `vehicle_type` int(11) NOT NULL,
  PRIMARY KEY (`parking_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `parking_log` VALUES("1","5","21212121","2024-09-23 11:04:12",NULL,"Jobert Simbre","2024-11-13","3");
INSERT INTO `parking_log` VALUES("2","7","12312312","2024-11-18 06:12:13",NULL,"Jobert Simbre","2024-11-17","2");



DROP TABLE IF EXISTS `system_data`;

CREATE TABLE `system_data` (
  `system_id` int(11) NOT NULL AUTO_INCREMENT,
  `system_function` text NOT NULL,
  `data_value` text NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`system_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `system_data` VALUES("1","login_qr","Mama mo","QR data to open entrance gate");
INSERT INTO `system_data` VALUES("2","logout_qr","Mama mo bayot","QR data to open exit gate");
INSERT INTO `system_data` VALUES("3","motorcycle_slot","30","Counts of available slots for motorcycles");
INSERT INTO `system_data` VALUES("4","car_slot","20","Counts of available slots for cars");
INSERT INTO `system_data` VALUES("5","tricycle_slots","15","Counts of available slots for tricycle");



DROP TABLE IF EXISTS `token`;

CREATE TABLE `token` (
  `token_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `token_code` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`token_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `token` VALUES("1","7","456179","0000-00-00 00:00:00");



DROP TABLE IF EXISTS `user_details`;

CREATE TABLE `user_details` (
  `user_d_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `firstname` varchar(32) NOT NULL,
  `lastname` varchar(32) NOT NULL,
  `middlename` varchar(32) NOT NULL,
  `department` int(2) NOT NULL,
  `year_group` int(2) NOT NULL,
  `section` varchar(32) NOT NULL,
  `mv_file` varchar(32) NOT NULL,
  `body_number` text NOT NULL,
  PRIMARY KEY (`user_d_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `user_details` VALUES("1","3","Jobert","Simbre","Gosuico","1","1","1","12312312","21321123");
INSERT INTO `user_details` VALUES("2","4","Jobert","Simbre","Gosuico","1","1","1","12312312","12312312");



DROP TABLE IF EXISTS `user_logs`;

CREATE TABLE `user_logs` (
  `user_log_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `username` text NOT NULL,
  `action` text NOT NULL,
  PRIMARY KEY (`user_log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=203 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `user_logs` VALUES("46","1","Administrator","Logged out on the system");
INSERT INTO `user_logs` VALUES("47","6","Jobert Simbre","Logged to the system");
INSERT INTO `user_logs` VALUES("48","6","Jobert Simbre","Logged out on the system");
INSERT INTO `user_logs` VALUES("49","6","Jobert Simbre","Logged to the system");
INSERT INTO `user_logs` VALUES("50","6","Jobert Simbre","Logged out on the system");
INSERT INTO `user_logs` VALUES("51","1","Administrator","Logged to the system");
INSERT INTO `user_logs` VALUES("52","1","Administrator","Logged out on the system");
INSERT INTO `user_logs` VALUES("53","6","Jobert Simbre","Logged to the system");
INSERT INTO `user_logs` VALUES("54","1","Administrator","Logged to the system");
INSERT INTO `user_logs` VALUES("55","1","Administrator","Logged out on the system");
INSERT INTO `user_logs` VALUES("56","1"," ","Logged to the system");
INSERT INTO `user_logs` VALUES("57","1"," ","Logged out on the system");
INSERT INTO `user_logs` VALUES("58","6","Jobert Simbre","Logged to the system");
INSERT INTO `user_logs` VALUES("59","6","Jobert Simbre","Logged out on the system");
INSERT INTO `user_logs` VALUES("60","6","Jobert Simbre","Logged to the system");
INSERT INTO `user_logs` VALUES("61","6","Jobert Simbre","Logged to the system");
INSERT INTO `user_logs` VALUES("62","6","Jobert Simbre","Logged to the system");
INSERT INTO `user_logs` VALUES("63","6","Jobert Simbre","Logged to the system");
INSERT INTO `user_logs` VALUES("64","6","Jobert Simbre","Logged to the system");
INSERT INTO `user_logs` VALUES("65","6","Jobert Simbre","Logged to the system");
INSERT INTO `user_logs` VALUES("66","6","Jobert Simbre","Logged to the system");
INSERT INTO `user_logs` VALUES("67","6","Jobert Simbre","Logged to the system");
INSERT INTO `user_logs` VALUES("68","6","Jobert Simbre","Logged to the system");
INSERT INTO `user_logs` VALUES("69","1"," ","Logged to the system");
INSERT INTO `user_logs` VALUES("70","1"," ","Logged out on the system");
INSERT INTO `user_logs` VALUES("71","1","Administrator","Logged to the system");
INSERT INTO `user_logs` VALUES("72","1","Administrator","Logged out on the system");
INSERT INTO `user_logs` VALUES("73","1","Administrator","Logged to the system");
INSERT INTO `user_logs` VALUES("74","1","Administrator","Logged out on the system");
INSERT INTO `user_logs` VALUES("75","1","Administrator","Logged to the system");
INSERT INTO `user_logs` VALUES("76","1","Administrator","Logged to the system");
INSERT INTO `user_logs` VALUES("77","1","Administrator","Backup the database named backup-parking_system-October_5_2024_8-26_pm.sql.gz");
INSERT INTO `user_logs` VALUES("78","1","Administrator","Restore the database using backup-parking_system-October_5_2024_8-26_pm.sql.gz");
INSERT INTO `user_logs` VALUES("79","1","Administrator","Backup the database named backup-parking_system-October_6_2024_2-34_am.sql.gz");
INSERT INTO `user_logs` VALUES("80","1","Administrator","Backup the database named backup-parking_system-October_6_2024_2-35_am.sql.gz");
INSERT INTO `user_logs` VALUES("81","1","Administrator","Backup the database named backup-parking_system-October_6_2024_2-35_am.sql.gz");
INSERT INTO `user_logs` VALUES("82","1","Administrator","Backup the database named backup-parking_system-October_6_2024_2-36_am.sql.gz");
INSERT INTO `user_logs` VALUES("83","1","Administrator","Backup the database named backup-parking_system-October_6_2024_2-36_am.sql.gz");
INSERT INTO `user_logs` VALUES("84","1","Administrator","Backup the database named backup-parking_system-October_6_2024_2-37_am.sql.gz");
INSERT INTO `user_logs` VALUES("85","1","Administrator","Restore the database using backup-parking_system-October_6_2024_2-37_am.sql.gz");
INSERT INTO `user_logs` VALUES("86","1","Administrator","Backup the database named backup-parking_system-October_6_2024_2-37_am.sql.gz");
INSERT INTO `user_logs` VALUES("87","1","Administrator","Restore the database using backup-parking_system-October_6_2024_2_37_am.sql.gz");
INSERT INTO `user_logs` VALUES("88","1","Administrator","Backup the database named backup-parking_system-October_6_2024_3-21_am.sql.gz");
INSERT INTO `user_logs` VALUES("89","1","Administrator","Restore the database using backup-parking_system-October_6_2024_3_21_am.sql.gz");
INSERT INTO `user_logs` VALUES("90","1","Administrator","Backup the database named backup-parking_system-October_6_2024_3-22_am.sql.gz");
INSERT INTO `user_logs` VALUES("91","1","Administrator","Restore the database using backup-parking_system-October_6_2024_3_22_am.sql.gz");
INSERT INTO `user_logs` VALUES("92","1","Administrator","Logged out on the system");
INSERT INTO `user_logs` VALUES("93","6","Jobert Simbre","Logged to the system");
INSERT INTO `user_logs` VALUES("94","6","Jobert Simbre","Logged out on the system");
INSERT INTO `user_logs` VALUES("95","1","Administrator","Logged to the system");
INSERT INTO `user_logs` VALUES("96","1","Administrator","Logged out on the system");
INSERT INTO `user_logs` VALUES("97","6","Guard","Logged to the system");
INSERT INTO `user_logs` VALUES("98","6","Guard","Logged out on the system");
INSERT INTO `user_logs` VALUES("99","1","Administrator","Logged to the system");
INSERT INTO `user_logs` VALUES("100","1","Administrator","Logged out on the system");
INSERT INTO `user_logs` VALUES("101","6","Guard","Logged to the system");
INSERT INTO `user_logs` VALUES("102","6","Guard","Logged out on the system");
INSERT INTO `user_logs` VALUES("103","1","Administrator","Logged to the system");
INSERT INTO `user_logs` VALUES("104","1","Administrator","Logged out on the system");
INSERT INTO `user_logs` VALUES("105","6","Guard","Logged to the system");
INSERT INTO `user_logs` VALUES("106","6","Guard","Logged out on the system");
INSERT INTO `user_logs` VALUES("107","1","Administrator","Logged to the system");
INSERT INTO `user_logs` VALUES("108","1","Administrator","Logged out on the system");
INSERT INTO `user_logs` VALUES("109","6","Guard","Logged to the system");
INSERT INTO `user_logs` VALUES("110","6","Guard","Logged out on the system");
INSERT INTO `user_logs` VALUES("111","1","Administrator","Logged to the system");
INSERT INTO `user_logs` VALUES("112","7","Jobert Simbre","Logged to the system");
INSERT INTO `user_logs` VALUES("113","1","Administrator","Logged to the system");
INSERT INTO `user_logs` VALUES("114","1","Administrator","Logged out on the system");
INSERT INTO `user_logs` VALUES("115","1","Administrator","Logged to the system");
INSERT INTO `user_logs` VALUES("116","1","Administrator","Logged out on the system");
INSERT INTO `user_logs` VALUES("117","7","Jobert Simbre","Logged to the system");
INSERT INTO `user_logs` VALUES("118","7","Jobert Simbre","Logged out on the system");
INSERT INTO `user_logs` VALUES("119","6","Guard","Logged to the system");
INSERT INTO `user_logs` VALUES("120","6","Guard","Logged out on the system");
INSERT INTO `user_logs` VALUES("121","7","Jobert Simbre","Logged to the system");
INSERT INTO `user_logs` VALUES("122","7","Jobert Simbre","Logged out on the system");
INSERT INTO `user_logs` VALUES("123","1","Administrator","Logged to the system");
INSERT INTO `user_logs` VALUES("124","1","Administrator","Logged out on the system");
INSERT INTO `user_logs` VALUES("125","6","Guard","Logged to the system");
INSERT INTO `user_logs` VALUES("126","6","Guard","Logged out on the system");
INSERT INTO `user_logs` VALUES("127","1","Administrator","Logged to the system");
INSERT INTO `user_logs` VALUES("128","1","Administrator","Logged out on the system");
INSERT INTO `user_logs` VALUES("129","7","Jobert Simbre","Logged into the system");
INSERT INTO `user_logs` VALUES("130","7","Jobert Simbre","Logged out on the system");
INSERT INTO `user_logs` VALUES("131","6","Guard","Logged into the system");
INSERT INTO `user_logs` VALUES("132","6","Guard","Logged out on the system");
INSERT INTO `user_logs` VALUES("133","1","Administrator","Logged into the system");
INSERT INTO `user_logs` VALUES("134","7","Jobert Simbre","Logged into the system");
INSERT INTO `user_logs` VALUES("135","7","Jobert Simbre","Logged into the system");
INSERT INTO `user_logs` VALUES("136","1","Administrator","Logged into the system");
INSERT INTO `user_logs` VALUES("137","1","Administrator","Backup the database named backup-parking_system-November_11_2024_12-41_pm.sql.gz");
INSERT INTO `user_logs` VALUES("138","1","Administrator","Logged into the system");
INSERT INTO `user_logs` VALUES("139","1","Administrator","Logged into the system");
INSERT INTO `user_logs` VALUES("140","1","Administrator","Backup the database named backup-parking_system-November_13_2024_11-42_am.sql.gz");
INSERT INTO `user_logs` VALUES("141","1","Administrator","Logged out on the system");
INSERT INTO `user_logs` VALUES("142","1","Administrator","Logged into the system");
INSERT INTO `user_logs` VALUES("143","6","Guard","Logged into the system");
INSERT INTO `user_logs` VALUES("144","6","Guard","Logged out on the system");
INSERT INTO `user_logs` VALUES("145","1","Administrator","Logged into the system");
INSERT INTO `user_logs` VALUES("146","1","Administrator","Logged out on the system");
INSERT INTO `user_logs` VALUES("147","7","Jobert Simbre","Logged into the system");
INSERT INTO `user_logs` VALUES("148","7","Jobert Simbre","Logged out on the system");
INSERT INTO `user_logs` VALUES("149","1","Administrator","Logged into the system");
INSERT INTO `user_logs` VALUES("150","1","Administrator","Logged out on the system");
INSERT INTO `user_logs` VALUES("151","6","Guard","Logged into the system");
INSERT INTO `user_logs` VALUES("152","6","Guard","Logged into the system");
INSERT INTO `user_logs` VALUES("153","6","Guard","Logged into the system");
INSERT INTO `user_logs` VALUES("154","6","Guard","Logged into the system");
INSERT INTO `user_logs` VALUES("155","6","Guard","Logged into the system");
INSERT INTO `user_logs` VALUES("156","6","Guard","Logged into the system");
INSERT INTO `user_logs` VALUES("157","6","Guard","Logged out on the system");
INSERT INTO `user_logs` VALUES("158","6","Guard","Logged into the system");
INSERT INTO `user_logs` VALUES("159","6","Guard","Logged into the system");
INSERT INTO `user_logs` VALUES("160","6","Guard","Logged into the system");
INSERT INTO `user_logs` VALUES("161","6","Guard","Logged into the system");
INSERT INTO `user_logs` VALUES("162","6","Guard","Logged out on the system");
INSERT INTO `user_logs` VALUES("163","7","Jobert Simbre","Logged into the system");
INSERT INTO `user_logs` VALUES("164","1","Administrator","Logged into the system");
INSERT INTO `user_logs` VALUES("165","7","Jobert Simbre","Logged into the system");
INSERT INTO `user_logs` VALUES("166","7","Jobert Simbre","Logged out on the system");
INSERT INTO `user_logs` VALUES("167","7","Jobert Simbre","Logged into the system");
INSERT INTO `user_logs` VALUES("168","7","Jobert Simbre","Logged out on the system");
INSERT INTO `user_logs` VALUES("169","1","Administrator","Logged into the system");
INSERT INTO `user_logs` VALUES("170","1","Administrator","Logged out on the system");
INSERT INTO `user_logs` VALUES("171","7","Jobert Simbre","Logged into the system");
INSERT INTO `user_logs` VALUES("172","7","Jobert Simbre","Logged out on the system");
INSERT INTO `user_logs` VALUES("173","7","Jobert Simbre","Logged into the system");
INSERT INTO `user_logs` VALUES("174","7","Jobert Simbre","Logged out on the system");
INSERT INTO `user_logs` VALUES("175","7","Jobert Simbre","Logged into the system");
INSERT INTO `user_logs` VALUES("176","7","Jobert Simbre","Logged out on the system");
INSERT INTO `user_logs` VALUES("177","1","Administrator","Logged into the system");
INSERT INTO `user_logs` VALUES("178","1","Administrator","Logged out on the system");
INSERT INTO `user_logs` VALUES("179","7","Jobert Simbre","Logged into the system");
INSERT INTO `user_logs` VALUES("180","7","Jobert Simbre","Logged out on the system");
INSERT INTO `user_logs` VALUES("181","7","Jobert Simbre","Logged into the system");
INSERT INTO `user_logs` VALUES("182","7","Jobert Simbre","Logged into the system");
INSERT INTO `user_logs` VALUES("183","7","Jobert Simbre","Logged out on the system");
INSERT INTO `user_logs` VALUES("184","7","Jobert Simbre","Logged into the system");
INSERT INTO `user_logs` VALUES("185","7","Jobert Simbre","Logged into the system");
INSERT INTO `user_logs` VALUES("186","7","Jobert Simbre","Logged out on the system");
INSERT INTO `user_logs` VALUES("187","1","Administrator","Logged into the system");
INSERT INTO `user_logs` VALUES("188","1","Administrator","Logged into the system");
INSERT INTO `user_logs` VALUES("189","1","Administrator","Logged out on the system");
INSERT INTO `user_logs` VALUES("190","7","Jobert Simbre","Logged into the system");
INSERT INTO `user_logs` VALUES("191","7","Jobert Simbre","Logged out on the system");
INSERT INTO `user_logs` VALUES("192","6","Guard","Logged into the system");
INSERT INTO `user_logs` VALUES("193","6","Guard","Logged out on the system");
INSERT INTO `user_logs` VALUES("194","1","Administrator","Logged into the system");
INSERT INTO `user_logs` VALUES("195","1","Administrator","Logged out on the system");
INSERT INTO `user_logs` VALUES("196","6","Guard","Logged into the system");
INSERT INTO `user_logs` VALUES("197","6","Guard","Logged out on the system");
INSERT INTO `user_logs` VALUES("198","1","Administrator","Logged into the system");
INSERT INTO `user_logs` VALUES("199","7","Jobert Simbre","Logged into the system");
INSERT INTO `user_logs` VALUES("200","7","Jobert Simbre","Logged out on the system");
INSERT INTO `user_logs` VALUES("201","1","Administrator","Logged into the system");
INSERT INTO `user_logs` VALUES("202","1","Administrator","Backup the database named backup-parking_system-December_16_2024_9-35_am.sql.gz");



DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_type` int(11) NOT NULL DEFAULT 2,
  `firstname` varchar(32) NOT NULL,
  `lastname` varchar(32) NOT NULL,
  `middlename` varchar(32) NOT NULL,
  `department` int(2) NOT NULL,
  `year_group` int(2) NOT NULL,
  `section` int(2) NOT NULL,
  `mv_file` text NOT NULL,
  `body_number` text NOT NULL,
  `vehicle_type` int(2) NOT NULL,
  `user_status` int(2) NOT NULL DEFAULT 0,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `users` VALUES("1","admin@access.com","$2y$10$N.SRTPJ9o63NISilP0gH..1naevj1Juu/k7N3un19QWW0aoqhptNq","2024-09-08 23:37:38","2024-09-08 23:37:38","1","","","","0","0","0","","","0","1");
INSERT INTO `users` VALUES("6","guard@access.com","$2y$10$di8sBOBiMq0MqNjlAqf4w.tH3HEwJP4V3lUCD2wx4Kjocf4ZWkHxe","2024-09-23 11:53:08","2024-09-23 11:53:08","3","","","","0","0","0","","","0","1");
INSERT INTO `users` VALUES("7","jobert.simbre014@gmail.com","$2y$10$TH7yn1ERpLa2mIACEKaxKOlsOcFCFzLjMlIUGRtQncYPHks5vNlqS","2024-09-20 02:40:35","2024-09-30 02:40:35","2","Jobert","Simbre","Gosuico","1","1","3","12312312","312312","3","1");
INSERT INTO `users` VALUES("8","asdas@asdas.caa","$2y$10$J1SyCXc0W5EmP/xci2t3vOzdy8zv/sq0oYoDrvUZshZHOpQTVYvJa","2024-11-17 10:45:59","2024-11-17 11:31:59","2","Asdasdas","Asdas","Gosuico","1","1","1","12312312121","12312312","1","0");
INSERT INTO `users` VALUES("9","asdas@asdas.cad","$2y$10$laqZyqKJJ0pR8WCU9txmpO10je8sWOQFh6uXWAe1kHPOARNBxLIru","2024-01-10 13:30:56","2024-11-13 12:31:01","2","Adasd","Simbre","Asdasdas","1","1","1","12312","1321","1","0");
