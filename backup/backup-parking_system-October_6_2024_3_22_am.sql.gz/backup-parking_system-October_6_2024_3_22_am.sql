CREATE DATABASE IF NOT EXISTS `parking_system`;

USE parking_system;

DROP TABLE IF EXISTS `parking_log`;

CREATE TABLE `parking_log` (
  `parking_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_mv_file` int(11) NOT NULL,
  `time_in` timestamp NOT NULL DEFAULT current_timestamp(),
  `time_out` timestamp NULL DEFAULT NULL,
  `username` text NOT NULL,
  `parking_date` date NOT NULL,
  `vehicle_type` int(11) NOT NULL,
  PRIMARY KEY (`parking_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `parking_log` VALUES("1","5","21212121","2024-09-23 11:04:12",NULL,"Jobert Simbre","2024-09-23","3");



DROP TABLE IF EXISTS `user_details`;

CREATE TABLE `user_details` (
  `user_d_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `firstname` varchar(32) NOT NULL,
  `lastname` varchar(32) NOT NULL,
  `middlename` varchar(32) NOT NULL,
  `department` int(2) NOT NULL,
  `year_group` int(2) NOT NULL,
  `section` varchar(32) NOT NULL,
  `mv_file` varchar(32) NOT NULL,
  `body_number` text NOT NULL,
  PRIMARY KEY (`user_d_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `user_details` VALUES("1","3","Jobert","Simbre","Gosuico","1","1","1","12312312","21321123");
INSERT INTO `user_details` VALUES("2","4","Jobert","Simbre","Gosuico","1","1","1","12312312","12312312");



DROP TABLE IF EXISTS `user_logs`;

CREATE TABLE `user_logs` (
  `user_log_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `username` text NOT NULL,
  `action` text NOT NULL,
  PRIMARY KEY (`user_log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `user_logs` VALUES("46","1","Administrator","Logged out on the system");
INSERT INTO `user_logs` VALUES("47","6","Jobert Simbre","Logged to the system");
INSERT INTO `user_logs` VALUES("48","6","Jobert Simbre","Logged out on the system");
INSERT INTO `user_logs` VALUES("49","6","Jobert Simbre","Logged to the system");
INSERT INTO `user_logs` VALUES("50","6","Jobert Simbre","Logged out on the system");
INSERT INTO `user_logs` VALUES("51","1","Administrator","Logged to the system");
INSERT INTO `user_logs` VALUES("52","1","Administrator","Logged out on the system");
INSERT INTO `user_logs` VALUES("53","6","Jobert Simbre","Logged to the system");
INSERT INTO `user_logs` VALUES("54","1","Administrator","Logged to the system");
INSERT INTO `user_logs` VALUES("55","1","Administrator","Logged out on the system");
INSERT INTO `user_logs` VALUES("56","1"," ","Logged to the system");
INSERT INTO `user_logs` VALUES("57","1"," ","Logged out on the system");
INSERT INTO `user_logs` VALUES("58","6","Jobert Simbre","Logged to the system");
INSERT INTO `user_logs` VALUES("59","6","Jobert Simbre","Logged out on the system");
INSERT INTO `user_logs` VALUES("60","6","Jobert Simbre","Logged to the system");
INSERT INTO `user_logs` VALUES("61","6","Jobert Simbre","Logged to the system");
INSERT INTO `user_logs` VALUES("62","6","Jobert Simbre","Logged to the system");
INSERT INTO `user_logs` VALUES("63","6","Jobert Simbre","Logged to the system");
INSERT INTO `user_logs` VALUES("64","6","Jobert Simbre","Logged to the system");
INSERT INTO `user_logs` VALUES("65","6","Jobert Simbre","Logged to the system");
INSERT INTO `user_logs` VALUES("66","6","Jobert Simbre","Logged to the system");
INSERT INTO `user_logs` VALUES("67","6","Jobert Simbre","Logged to the system");
INSERT INTO `user_logs` VALUES("68","6","Jobert Simbre","Logged to the system");
INSERT INTO `user_logs` VALUES("69","1"," ","Logged to the system");
INSERT INTO `user_logs` VALUES("70","1"," ","Logged out on the system");
INSERT INTO `user_logs` VALUES("71","1","Administrator","Logged to the system");
INSERT INTO `user_logs` VALUES("72","1","Administrator","Logged out on the system");
INSERT INTO `user_logs` VALUES("73","1","Administrator","Logged to the system");
INSERT INTO `user_logs` VALUES("74","1","Administrator","Logged out on the system");
INSERT INTO `user_logs` VALUES("75","1","Administrator","Logged to the system");
INSERT INTO `user_logs` VALUES("76","1","Administrator","Logged to the system");
INSERT INTO `user_logs` VALUES("77","1","Administrator","Backup the database named backup-parking_system-October_5_2024_8-26_pm.sql.gz");
INSERT INTO `user_logs` VALUES("78","1","Administrator","Restore the database using backup-parking_system-October_5_2024_8-26_pm.sql.gz");
INSERT INTO `user_logs` VALUES("79","1","Administrator","Backup the database named backup-parking_system-October_6_2024_2-34_am.sql.gz");
INSERT INTO `user_logs` VALUES("80","1","Administrator","Backup the database named backup-parking_system-October_6_2024_2-35_am.sql.gz");
INSERT INTO `user_logs` VALUES("81","1","Administrator","Backup the database named backup-parking_system-October_6_2024_2-35_am.sql.gz");
INSERT INTO `user_logs` VALUES("82","1","Administrator","Backup the database named backup-parking_system-October_6_2024_2-36_am.sql.gz");
INSERT INTO `user_logs` VALUES("83","1","Administrator","Backup the database named backup-parking_system-October_6_2024_2-36_am.sql.gz");
INSERT INTO `user_logs` VALUES("84","1","Administrator","Backup the database named backup-parking_system-October_6_2024_2-37_am.sql.gz");
INSERT INTO `user_logs` VALUES("85","1","Administrator","Restore the database using backup-parking_system-October_6_2024_2-37_am.sql.gz");
INSERT INTO `user_logs` VALUES("86","1","Administrator","Backup the database named backup-parking_system-October_6_2024_2-37_am.sql.gz");
INSERT INTO `user_logs` VALUES("87","1","Administrator","Restore the database using backup-parking_system-October_6_2024_2_37_am.sql.gz");
INSERT INTO `user_logs` VALUES("88","1","Administrator","Backup the database named backup-parking_system-October_6_2024_3-21_am.sql.gz");
INSERT INTO `user_logs` VALUES("89","1","Administrator","Restore the database using backup-parking_system-October_6_2024_3_21_am.sql.gz");
INSERT INTO `user_logs` VALUES("90","1","Administrator","Backup the database named backup-parking_system-October_6_2024_3-22_am.sql.gz");



DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_type` int(11) NOT NULL DEFAULT 2,
  `firstname` varchar(32) NOT NULL,
  `lastname` varchar(32) NOT NULL,
  `middlename` varchar(32) NOT NULL,
  `department` int(2) NOT NULL,
  `year_group` int(2) NOT NULL,
  `section` int(2) NOT NULL,
  `mv_file` text NOT NULL,
  `body_number` text NOT NULL,
  `vehicle_type` int(2) NOT NULL,
  `user_status` int(2) NOT NULL DEFAULT 0,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `users` VALUES("1","admin@access.com","$2y$10$N.SRTPJ9o63NISilP0gH..1naevj1Juu/k7N3un19QWW0aoqhptNq","2024-09-08 23:37:38","2024-09-08 23:37:38","1","","","","0","0","0","","","0","1");
INSERT INTO `users` VALUES("6","jobert.simbre14@gmail.com","$2y$10$di8sBOBiMq0MqNjlAqf4w.tH3HEwJP4V3lUCD2wx4Kjocf4ZWkHxe","2024-09-23 11:53:08","2024-09-23 11:53:08","2","Jobert","Simbre","Gosuico","1","4","1","12312312","21321123","2","0");
INSERT INTO `users` VALUES("7","jobert.simbre014@gmail.com","$2y$10$ZMBB55Yf7bmlcDy919eNX.er8327PLqVNhXpy8bZ5S9D3e0SiFhpC","2024-09-20 02:40:35","2024-09-30 02:40:35","2","Jebert","Smbre","Gosuica","1","1","3","12312312","312312","3","0");
